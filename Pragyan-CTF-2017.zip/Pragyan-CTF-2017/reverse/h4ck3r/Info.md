# Finding the flag

To find the flag, we have two options.

1. Give the flag once the person reverses the executable. But this would become easy since the executable *might* be prone to vulnerabilities and could be reversed easily.
2. Make them reverse the exe and include an exploit like remote root.

Depending on what option we choose, the file can be modified.  
