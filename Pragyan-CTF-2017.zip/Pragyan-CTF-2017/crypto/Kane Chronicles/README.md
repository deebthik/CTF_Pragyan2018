# Kane Chronicles

You are Caesar Kane, living in 2650 BC, Ancient Egypt. A random traveller gives you some dates to eat and the following message. The sender being clever, doesn't encrypt the message but chooses to encrypt his sign at the end. Decode the message and find the sender.

Dear Magician,

  I know who you are. I wish to aid you on your steps to find the flag. The steps are tough and you'll need 5 clues. Find me.

  Regards,
  
  asocdvspauqbeo

Image Link - https://www.google.co.in/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&cad=rja&uact=8&ved=0ahUKEwix8pOe_NfQAhWJuY8KHWeaAbIQjRwIBw&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FStep_pyramid&psig=AFQjCNHYZqsNH0AfAuDHwmvdhHTorWnzYw&ust=1480852660877508
