Solution
--------

Use vignere with pragyan as key to get question

Solve it to get Algorithms

Algorithms is to be decoded with pragyan+vignere

gives you lugitigsvs
