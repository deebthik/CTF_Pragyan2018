# h4ck3r

The source code is given and it is a creditcard number generator. Depending on where we choose to keep the flag (idk how this part works) we could modify the source code and run it. Source code is attached for Proof of Concept.

Key: - (yet to be decided)
