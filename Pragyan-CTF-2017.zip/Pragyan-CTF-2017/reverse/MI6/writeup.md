# h4ck3r

As we can see, we have a random sequence of characters from 20-30. Simple calculations and a bit of bruteforcing will give us the flag. Since the flag format has not been decided, I uploaded a very simple pragyanctf-{} in place of the flag.

Source: - Attached for POC
Key: - Not yet finalized
