The answer to everything
====================
Kushal has got a binary. It contains the name of a wise man, and his flag. He is unable to solve it. 

Submit the flag to unlock the secrets of the universe :p
BTW Remember the format :  pragyan_ctf{flag}
