# Kane Chronicles

From the clue, we can see that it is some variant of a substituted cipher. But it is not Vigenere's cipher??? Hmm.. It is acutally a modified version of caesar's cipher. It involves incrementing steps on each try. In this case, the code is incremented in steps of 5. By knowing the total number of characters in the script, we can figure out the total offset for each value. A script or even extended patience can fetch you the key.

Source:- POC

  22 27 1
  9 19  19
  26 41 15
  9 29  3
  5 30  4
  18 48 22

  11 46 20
  2 42  16

  8 53  1
  23 73 21
  14 69 17
  20 80 2
  18 83 5
  23 93 15

Key: - vizierkbhwntrw
