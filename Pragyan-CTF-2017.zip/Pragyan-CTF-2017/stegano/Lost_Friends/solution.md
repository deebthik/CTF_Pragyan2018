## Lost Friends - Solution

At first, the image is completely blank, or transparent.
Basically, in the image, of the RGBA values, the value of A (Alpha) is 0 for all pixels, so it's transparent.

So, first we set the value of A for all pixels to be 255. In the resulting image, we can see that there are differing shades of red, green and blue. 
We split the image in the respective colours, getting three different images.

The images are of the three chipmunks (Alvin and the Three Chipmunks). 
From the question description, we can see that it is related to something with shipwreck, or some tragedies in the sea.
There is a movie, titled "Alvin and the Chipmunks: Chipwrecked", in the sequel, directed by "Mike Mitchell". 

The original image also contains a message that states about a Director. So, we have the director name of that movie as the flag.

FLAG is :-   mikemitchell
