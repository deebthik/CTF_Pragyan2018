# Server Requirements

The user is desired to first capture the cookie token when he first logs in. The cookie would contain the details of the user he has to login as in order to get the flag. The player is then expected to login as the user and the welcome page of the user will contain the flag. A sample phantomjs script with a cookie has been attached for reference. This would work with the main login page.
