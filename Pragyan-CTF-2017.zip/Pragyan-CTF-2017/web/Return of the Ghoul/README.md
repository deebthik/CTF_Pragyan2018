# Return of the Ghoul
### The Ghoul Part-2

The Ghoul has taken training from the Riddler and has decided to come up with a more sophisticated challenge. The flag is a text file located at /findme. Retrieve the flag to get the next clue regarding the identity of the Ghoul.
