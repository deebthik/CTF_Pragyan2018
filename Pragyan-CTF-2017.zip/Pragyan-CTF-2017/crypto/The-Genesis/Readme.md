# The Genesis
### 100 points

- The required assets are found along with Genesis.md in this folder.
- Verify PGP keys to confirm authenticity of creator as "Varunram Ganesh       <varunramg@live.com> "
- Try it out and wait for solution

Have Fun with the Genesis.
Good Luck.
