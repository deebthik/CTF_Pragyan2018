# DocOc

Spidey has few chest congestion problems so he went to see DocOc for remedies. DocOc however mixed the scan results gicing him a CRT scan report instead of a CT scan report. Decode the Report.

Hello Spidey,
Your Cure is 7400127

Good Luck,
Doctor Octupus

*The RSA key is just a placeholder for the real flag*
