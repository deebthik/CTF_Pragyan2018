# The Karaboudjan

### The Easy way:-
Simply crack the zip and open the pcap file to get free points.

### The Long Way:-
Convert the brainfuck text given to get the password. Open the zip with the password "dissect" to get the pcap file. Open with wireshark and the key is there.

A very easy question.
