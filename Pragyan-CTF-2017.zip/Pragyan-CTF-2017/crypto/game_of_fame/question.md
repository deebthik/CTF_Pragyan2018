pragyan winner of game of fame
------------
p xasc. a zdmik qtng. yiy uist. easc os iye iq trmkbumk. gwv wolnrg kaqcs vi rlr.

PS : Submit flag as pragyan_ctf{flag}
