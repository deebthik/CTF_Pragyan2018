# Captain Haddock

Captain Haddock is on one of his ship sailing journeys when he gets stranded off the coast of North Korea. He finds shelter off a used nuke and decides to use the seashells to engrave a message on a piece of paper. Decrypt the message and save Captain Haddock.

-[--->+<]>-.[---->+++++<]>-.---.--[--->+<]>-.[-->+++++++<]>.[----->++<]>+.--[--->+<]>--..++++.--------.+++.--------------.-[--->+<]>-.-[--->++<]>-.++++++++++.+[---->+<]>+++.++.-[->+++<]>+.+++++.++++++++++..++++[->+++<]>.--.-[--->+<]>--.[-->+++++<]>.
