# 100 points - Crypto+Steg
# The Genesis

## Important Rules for the Question

1. There are two files related to this question - both **may** be necessart to solve the question

2. Links will be up shortly, no worries
 
3. Solution is ready and will be posted in due time
