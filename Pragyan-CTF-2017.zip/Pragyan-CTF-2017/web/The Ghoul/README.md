# The Ghoul
### Part-1

A Ghoul has been lurking around the premises of Gotham for a long time. This time, the Bat has recovered a critical clue which might lead to the Ghoul being captured. The Ghoul being clever, has split his identity into three parts. Help the Bat and Oracle identify the Ghoul so that Gotham is saved.
