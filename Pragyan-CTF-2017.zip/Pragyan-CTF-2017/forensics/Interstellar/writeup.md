# Interstellar
### Part 1 of a two question series.

Another easy question off forensics. From the file, we can deduce that the RGB values have been messed up a bit. Experimenting with the RGB values would finally give the key. Meant to provide a start to the second part.
