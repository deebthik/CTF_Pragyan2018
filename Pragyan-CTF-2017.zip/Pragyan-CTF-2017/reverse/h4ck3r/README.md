# h4ck3r

A friend wants you to reverse a script.

> Hey Mate,

> I have developed this script to hack the World Bank but it seems to have gone rogue.
> Can you help me fix it?
>
> Regards,
> Your friendly neighborhood h4ck3r
