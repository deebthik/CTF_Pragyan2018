# The Ghoul

This is Part 1 of a three part question series. The first part is intended to be easy so that people can progress to the relatively more difficult second and third parts. The first part would involve a simple CSRF bypass so that the participants can gain access to the flag. The index.php file is attached but the flag has to be attached to the main server frame.
